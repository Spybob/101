ldapsearch "sn=*bon*" | grep -c 'dn'
