ldapsearch cn | grep -i "cn: z" | sort -r | cut -c5-
